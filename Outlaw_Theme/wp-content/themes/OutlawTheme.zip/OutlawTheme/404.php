<!-- main content area for Wordpress theme -->
<?php get_header(); ?>
<div id="contentWrap">

	<div id="content">
 		<h3>Page not found?</h3><br>
        <h2>How embarassing!</h2>
        <p>Must have been the whiskey.</p>
    </div><!-- end of content -->
    	<?php get_sidebar (); ?>
</div><!-- end of contentWrap -->
<?php get_footer(); ?>
