<!-- opening tags exist in header doc -->

	<footer>
		<p>Copyright &copy; <?php echo date("Y"); echo " "; bloginfo('name'); ?></p>

	</footer>
    </div> <!-- end of outerWrapper-->
</body>
</html>